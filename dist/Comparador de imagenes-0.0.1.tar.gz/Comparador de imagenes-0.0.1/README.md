# Imagen_processing


Description.

    Processing:

* Histrogram matching
* Structural similarity
* Resize image


## Installation

Use the package manager [pip](https://pip.pypa.io/en/stable/) to install package_name


```bash
pip install imagen_processing
```

## Author

Esteban Gonzalez

## LIcense

[MLT](https://choosealicence.com\\licences/mit/)
